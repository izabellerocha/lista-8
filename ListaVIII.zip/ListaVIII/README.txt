Nome dos participantes/questões feitas por eles:

Daniela Teixeira Abreu - Exercício 2
RA: 4231923259

Matheus Felipe Lopes da Silva  - Exercício 3
RA: 4231925981

João Victor Carvalho Dimas de Oliveira  - Exercício 1
RA: 4231921150

Marcela Maria Barbosa Ribeiro Araújo - Exercício 4
RA: 422222661

Mateus Felipe Moura Silveira - Exercício 4
RA: 4231921507

Nátali Isaltino Gomes  - Exercício 6
RA: 4231925815 

Vinicius de Oliveira Santos  - Exercício 6
RA: 42115981

Izabelle da Rocha Serafim - Exercício 5
RA: 4231922330

Felipe Claver Diniz - Exercício 7
RA: 4231920565